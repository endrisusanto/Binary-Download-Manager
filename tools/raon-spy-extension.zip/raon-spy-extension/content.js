(function () {
  // Ponytail: Keep it single-file, no-boilerplate, self-contained main-world injection
  const spyCode = `
    (function() {
      const log = (title, details, type = 'info') => {
        const colors = {
          info: '#3B82F6',
          success: '#10B981',
          warning: '#F59E0B',
          error: '#EF4444'
        };
        const color = colors[type] || colors.info;
        console.groupCollapsed(
          \`%c[RAON SPY] ${title}\`,
          \`color: ${color}; font-weight: bold; font-size: 11px; padding: 2px 4px; border-radius: 3px; background: rgba(0,0,0,0.05);\`
        );
        console.log('Timestamp:', new Date().toLocaleTimeString());
        if (details) {
          if (typeof details === 'object') {
            console.dir(details);
          } else {
            console.log(details);
          }
        }
        console.groupEnd();
      };

      log('RAONK Downloader Spy Active', 'Monitoring network requests, XMLHttpRequests, Fetch, WebSockets, and Forms.');

      // 1. Intercept XMLHttpRequest
      const OriginalXHR = window.XMLHttpRequest;
      function SpyXHR() {
        const xhr = new OriginalXHR();
        const send = xhr.send;
        const open = xhr.open;
        let method = '';
        let url = '';
        let requestHeaders = {};

        xhr.open = function(m, u, ...args) {
          method = m;
          url = u;
          return open.apply(xhr, [m, u, ...args]);
        };

        const setRequestHeader = xhr.setRequestHeader;
        xhr.setRequestHeader = function(header, value) {
          requestHeaders[header] = value;
          return setRequestHeader.apply(xhr, [header, value]);
        };

        xhr.send = function(body) {
          const isTarget = url.includes('127.0.0.1') || url.includes('localhost') || url.includes('raonk') || url.includes('kupload') || url.includes('Download') || url.includes('Download');
          
          if (isTarget) {
            log(\`XHR Request: \${method} \${url}\`, {
              url,
              method,
              headers: requestHeaders,
              body: body
            }, 'warning');

            xhr.addEventListener('load', () => {
              log(\`XHR Response: \${url} [\${xhr.status}]\`, {
                status: xhr.status,
                responseText: xhr.responseText
              }, xhr.status >= 200 && xhr.status < 300 ? 'success' : 'error');
            });
          }
          return send.apply(xhr, [body]);
        };

        return xhr;
      }
      // Inherit prototype
      SpyXHR.prototype = OriginalXHR.prototype;
      Object.assign(SpyXHR, OriginalXHR);
      window.XMLHttpRequest = SpyXHR;

      // 2. Intercept Fetch
      const originalFetch = window.fetch;
      window.fetch = async function(resource, init) {
        const url = typeof resource === 'string' ? resource : (resource.url || '');
        const method = (init && init.method) || 'GET';
        const isTarget = url.includes('127.0.0.1') || url.includes('localhost') || url.includes('raonk') || url.includes('kupload') || url.includes('Download');

        if (isTarget) {
          log(\`Fetch Request: \${method} \${url}\`, {
            url,
            method,
            headers: (init && init.headers) || {},
            body: (init && init.body) || null
          }, 'warning');
        }

        try {
          const response = await originalFetch(resource, init);
          if (isTarget) {
            const clone = response.clone();
            clone.text().then(text => {
              log(\`Fetch Response: \${url} [\${response.status}]\`, {
                status: response.status,
                body: text
              }, response.status >= 200 && response.status < 300 ? 'success' : 'error');
            });
          }
          return response;
        } catch (err) {
          if (isTarget) {
            log(\`Fetch Failed: \${url}\`, err, 'error');
          }
          throw err;
        }
      };

      // 3. Intercept WebSockets
      const OriginalWebSocket = window.WebSocket;
      window.WebSocket = function(url, protocols) {
        log(\`WebSocket Connection Attempt: \${url}\`, { url, protocols }, 'warning');
        const ws = new OriginalWebSocket(url, protocols);
        
        ws.addEventListener('open', () => {
          log(\`WebSocket Opened: \${url}\`, null, 'success');
        });

        ws.addEventListener('message', (event) => {
          log(\`WebSocket Message Received from \${url}\`, event.data, 'info');
        });

        const originalSend = ws.send;
        ws.send = function(data) {
          log(\`WebSocket Message Sent to \${url}\`, data, 'info');
          return originalSend.apply(ws, [data]);
        };

        ws.addEventListener('close', (event) => {
          log(\`WebSocket Closed: \${url}\`, { code: event.code, reason: event.reason }, 'error');
        });

        return ws;
      };
      window.WebSocket.prototype = OriginalWebSocket.prototype;

      // 4. Intercept Form Submission
      window.addEventListener('submit', (event) => {
        const form = event.target;
        const action = form.action || '';
        const method = form.method || 'GET';
        
        const formData = {};
        const inputs = form.querySelectorAll('input, select, textarea');
        inputs.forEach(input => {
          if (input.name) {
            if (input.type === 'checkbox' || input.type === 'radio') {
              if (input.checked) formData[input.name] = input.value;
            } else {
              formData[input.name] = input.value;
            }
          }
        });

        log(\`Form Submitted to \${action} [\${method}]\`, {
          action,
          method,
          formData
        }, 'warning');
      }, true);

      // 5. Periodically inspect global RAONK objects if any
      setInterval(() => {
        const globals = ['RAONK', 'RAONK_Download', 'RAONK_Upload', 'KUpload', 'raonk_download', 'kupload'];
        globals.forEach(g => {
          if (window[g] && !window['__spy_logged_' + g]) {
            window['__spy_logged_' + g] = true;
            log(\`Detected Global Object: window.\${g}\`, window[g], 'success');
          }
        });
      }, 2000);
    })();
  `;

  // Inject the script into the main world page execution context
  const script = document.createElement('script');
  script.textContent = spyCode;
  (document.head || document.documentElement).appendChild(script);
  script.remove();
})();
